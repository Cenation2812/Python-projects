import scrapy


class ExampleSpider(scrapy.Spider):
    name = 'example'
    #allowed_domains = ['https://www.imdb.com/name/nm0000375/?ref_=nv_sr_1?ref_=nv_sr_1']
    #start_urls = ['https://www.imdb.com/name/nm0000375/?ref_=nv_sr_1?ref_=nv_sr_1/']

    def __init__(self):
        self.file_w = open("file1.txt", "w")
       
    def start_requests(self):
        urls = ['https://www.imdb.com/name/nm0000375/?ref_=nv_sr_1?ref_=nv_sr_1/']
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)


    def parse(self, response):
        print ("response is -------------->", response)
        urls=response.xpath('//div[@class="filmo-category-section"]//b//a/@href').extract()
        print ("urls is -------------->",urls)
        urls = ["https://www.imdb.com"+u for u in urls]
        for url in urls:
            print ("target-->", url)
            yield scrapy.Request(url=url, callback=self.fatch1)

    def fatch1(self, response):
        #//span[@class="AggregateRatingButton__RatingScore-sc-1ll29m0-1 iTLWoV"]
        title = response.xpath("//h1//text()").extract()[0]
        rating = response.xpath('//span[@class="AggregateRatingButton__RatingScore-sc-1ll29m0-1 iTLWoV"]//text()').extract()[0]
        #print ("title--------->", title, type(title))
        #print ("rating------->", rating, type(rating))
        data = title+","+rating+"\n" 
        self.file_w.write(data )
        
